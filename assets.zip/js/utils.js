const Storage = {
    get(key, defaultValue = null) {
        try {
            const value = localStorage.getItem(key);
            return value ? JSON.parse(value) : defaultValue;
        } catch {
            return defaultValue;
        }
    },

    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch {
            return false;
        }
    },

    remove(key) {
        localStorage.removeItem(key);
    },

    clear() {
        localStorage.clear();
    }
};

const Toast = {
    show(message, duration = 2000) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => toast.classList.add('show'), 10);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    success(message) {
        this.show(message);
    },

    error(message) {
        this.show(message);
    },

    warning(message) {
        this.show(message);
    }
};

const Modal = {
    show(content, onConfirm = null, onCancel = null) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">提示</div>
                <div class="modal-body">${content}</div>
                <div class="modal-footer">
                    <button class="btn btn-outline" id="modal-cancel">取消</button>
                    <button class="btn" id="modal-confirm">确定</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        setTimeout(() => modal.classList.add('show'), 10);
        
        const confirmBtn = modal.querySelector('#modal-confirm');
        const cancelBtn = modal.querySelector('#modal-cancel');
        
        confirmBtn.addEventListener('click', () => {
            modal.classList.remove('show');
            setTimeout(() => modal.remove(), 300);
            if (onConfirm) onConfirm();
        });
        
        cancelBtn.addEventListener('click', () => {
            modal.classList.remove('show');
            setTimeout(() => modal.remove(), 300);
            if (onCancel) onCancel();
        });
    },

    alert(content, onConfirm = null) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">提示</div>
                <div class="modal-body">${content}</div>
                <div class="modal-footer">
                    <button class="btn" id="modal-ok">确定</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        setTimeout(() => modal.classList.add('show'), 10);
        
        const okBtn = modal.querySelector('#modal-ok');
        okBtn.addEventListener('click', () => {
            modal.classList.remove('show');
            setTimeout(() => modal.remove(), 300);
            if (onConfirm) onConfirm();
        });
    },

    confirm(content, onConfirm = null, onCancel = null) {
        this.show(content, onConfirm, onCancel);
    }
};

const Voice = {
    enabled: false,
    utterance: null,

    init() {
        this.enabled = Storage.get('voiceEnabled', true);
    },

    setEnabled(value) {
        this.enabled = value;
        Storage.set('voiceEnabled', value);
    },

    speak(text) {
        if (!this.enabled) return;
        
        if (this.utterance) {
            window.speechSynthesis.cancel();
        }
        
        this.utterance = new SpeechSynthesisUtterance(text);
        this.utterance.lang = 'zh-CN';
        this.utterance.rate = 0.9;
        this.utterance.pitch = 1;
        this.utterance.volume = 1;
        
        window.speechSynthesis.speak(this.utterance);
    },

    stop() {
        if (this.utterance) {
            window.speechSynthesis.cancel();
            this.utterance = null;
        }
    }
};

const ImageCompressor = {
    compress(file, maxWidth = 800, maxHeight = 800) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    let width = img.width;
                    let height = img.height;
                    
                    if (width > maxWidth || height > maxHeight) {
                        const ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = width * ratio;
                        height = height * ratio;
                    }
                    
                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;
                    
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    const base64 = canvas.toDataURL('image/jpeg', 0.8);
                    resolve(base64);
                };
                img.onerror = reject;
                img.src = e.target.result;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }
};

const DateUtils = {
    format(date) {
        const d = new Date(date);
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    },

    isBefore(date1, date2) {
        return new Date(date1) < new Date(date2);
    },

    getDaysRemaining(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        const diff = end - start;
        return Math.floor(diff / (1000 * 60 * 60 * 24));
    },

    isValid(dateString) {
        const date = new Date(dateString);
        return date instanceof Date && !isNaN(date);
    }
};

const FaceDetector = {
    model: null,
    useTFJS: true,

    async loadModel() {
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                this.useTFJS = false;
                resolve(false);
            }, 15000);

            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs-core@4.10.0/dist/tf-core.min.js';
            script.onload = () => {
                const script2 = document.createElement('script');
                script2.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs-backend-webgl@4.10.0/dist/tf-backend-webgl.min.js';
                script2.onload = () => {
                    const script3 = document.createElement('script');
                    script3.src = 'https://cdn.jsdelivr.net/npm/@tensorflow-models/face-landmarks-detection@1.0.2/dist/face-landmarks-detection.min.js';
                    script3.onload = async () => {
                        try {
                            this.model = await faceLandmarksDetection.load(
                                faceLandmarksDetection.SupportedPackages.mediapipeFacemesh,
                                { maxNumFaces: 1 }
                            );
                            clearTimeout(timeout);
                            resolve(true);
                        } catch {
                            clearTimeout(timeout);
                            this.useTFJS = false;
                            resolve(false);
                        };
                    };
                    script3.onerror = () => {
                        clearTimeout(timeout);
                        this.useTFJS = false;
                        resolve(false);
                    };
                    document.head.appendChild(script3);
                };
                script2.onerror = () => {
                    clearTimeout(timeout);
                    this.useTFJS = false;
                    resolve(false);
                };
                document.head.appendChild(script2);
            };
            script.onerror = () => {
                clearTimeout(timeout);
                this.useTFJS = false;
                resolve(false);
            };
            document.head.appendChild(script);
        });
    },

    async detect(imageElement) {
        if (this.useTFJS && this.model) {
            try {
                const predictions = await this.model.estimateFaces({
                    input: imageElement,
                    returnTensors: false
                });
                return predictions.length > 0;
            } catch {
                return this.simpleDetect(imageElement);
            }
        }
        return this.simpleDetect(imageElement);
    },

    simpleDetect(imageElement) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = imageElement.width;
        canvas.height = imageElement.height;
        ctx.drawImage(imageElement, 0, 0);
        
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        
        let skinPixels = 0;
        let totalPixels = 0;
        
        for (let y = 0; y < canvas.height; y += 4) {
            for (let x = 0; x < canvas.width; x += 4) {
                const i = (y * canvas.width + x) * 4;
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                
                if (r > 95 && g > 40 && b > 20 && 
                    r > g && r > b && 
                    Math.abs(r - g) > 15 && 
                    (r - g) > (g - b) * 2) {
                    skinPixels++;
                }
                totalPixels++;
            }
        }
        
        return (skinPixels / totalPixels) > 0.05;
    }
};

const FaceShapeAnalyzer = {
    shapes: ['鹅蛋脸', '圆脸', '方脸', '长脸', '菱形脸', '心形脸', '三角脸', '椭圆形脸'],
    
    analyze(imageElement) {
        const width = imageElement.width;
        const height = imageElement.height;
        
        const aspectRatio = width / height;
        const centerX = width / 2;
        const centerY = height / 2;
        
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(imageElement, 0, 0);
        
        const imageData = ctx.getImageData(0, 0, width, height);
        const data = imageData.data;
        
        let skinPixels = [];
        for (let y = 0; y < height; y += 2) {
            for (let x = 0; x < width; x += 2) {
                const i = (y * width + x) * 4;
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                
                if (r > 95 && g > 40 && b > 20 && 
                    r > g && r > b && 
                    Math.abs(r - g) > 15) {
                    skinPixels.push({ x, y });
                }
            }
        }
        
        if (skinPixels.length === 0) {
            return this.shapes[0];
        }
        
        const minX = Math.min(...skinPixels.map(p => p.x));
        const maxX = Math.max(...skinPixels.map(p => p.x));
        const minY = Math.min(...skinPixels.map(p => p.y));
        const maxY = Math.max(...skinPixels.map(p => p.y));
        
        const faceWidth = maxX - minX;
        const faceHeight = maxY - minY;
        const faceRatio = faceWidth / faceHeight;
        
        const chinY = maxY;
        const foreheadY = minY;
        const cheekWidth = faceWidth;
        
        if (faceRatio < 0.8) return '长脸';
        if (faceRatio > 1.1) return '方脸';
        if (faceRatio > 0.95 && faceRatio < 1.1) return '圆脸';
        
        const topThird = skinPixels.filter(p => p.y < foreheadY + faceHeight / 3).length;
        const middleThird = skinPixels.filter(p => p.y >= foreheadY + faceHeight / 3 && p.y < foreheadY + faceHeight * 2 / 3).length;
        const bottomThird = skinPixels.filter(p => p.y >= foreheadY + faceHeight * 2 / 3).length;
        
        if (topThird > middleThird && topThird > bottomThird) return '心形脸';
        if (bottomThird > topThird && bottomThird > middleThird) return '三角脸';
        if (middleThird > topThird && middleThird > bottomThird) return '菱形脸';
        
        if (faceRatio >= 0.85 && faceRatio <= 0.95) return '鹅蛋脸';
        
        return '椭圆形脸';
    },

    getAnalysisText(shape) {
        const texts = {
            '鹅蛋脸': '您的脸型是鹅蛋脸，这是最理想的脸型，线条柔和流畅，适合各种妆容风格。建议重点突出眼部妆容，让整体造型更加精致动人。',
            '圆脸': '您的脸型是圆脸，脸部线条圆润可爱。建议使用修容打造脸部立体感，眉毛可以稍微拉长，让脸型看起来更加修长。',
            '方脸': '您的脸型是方脸，下颌线条分明，给人干练自信的感觉。建议用柔和的腮红和圆润的眉形来柔化脸部线条，增添女性柔美。',
            '长脸': '您的脸型是长脸，脸部线条修长优雅。建议在脸颊两侧增加横向修饰，缩短脸部视觉比例，同时注重眼部和唇部的平衡。',
            '菱形脸': '您的脸型是菱形脸，颧骨较为突出，额头和下巴较窄。建议通过高光和阴影来平衡面部轮廓，让颧骨看起来不那么突出。',
            '心形脸': '您的脸型是心形脸，额头较宽，下巴较尖。建议在下巴处增加高光，平衡面部比例，妆容重点可以放在眼部和嘴唇。',
            '三角脸': '您的脸型是三角脸，下颌较宽，额头较窄。建议在上半部分脸部增加体积感，使用高光提亮额头和太阳穴，让面部更加平衡。',
            '椭圆形脸': '您的脸型是椭圆形脸，轮廓优美，是经典的美人脸型。建议保持妆容的清新自然，突出五官的精致感即可。'
        };
        return texts[shape] || '您的脸型分析完成，适合多种妆容风格。';
    }
};

const MakeupReportGenerator = {
    generate(faceShape, originalImage, referenceImage) {
        const reports = {
            '鹅蛋脸': {
                matchScore: 95,
                differences: ['眼部轮廓略浅', '唇色饱和度稍低'],
                suggestions: [
                    '使用大地色系眼影打造深邃眼窝',
                    '叠加珠光眼影在眼皮中央提亮',
                    '选择蜜桃色腮红增添气色',
                    '使用豆沙色口红提升气质'
                ]
            },
            '圆脸': {
                matchScore: 88,
                differences: ['脸部立体感不足', '眉形不够清晰'],
                suggestions: [
                    '在颧骨下方使用修容粉',
                    '眉毛画成自然的拱形',
                    '眼线微微上扬拉长眼型',
                    '选择亮色系口红转移视觉焦点'
                ]
            },
            '方脸': {
                matchScore: 85,
                differences: ['下颌线条过于硬朗', '腮红位置偏高'],
                suggestions: [
                    '使用柔和的圆形腮红',
                    '修容重点放在下颌角',
                    '选择圆润的眉形',
                    '使用奶油质地的高光'
                ]
            },
            '长脸': {
                matchScore: 87,
                differences: ['额头过于饱满', '眼部间距偏宽'],
                suggestions: [
                    '在额头两侧使用修容',
                    '缩短眉毛长度',
                    '加强内眼角眼线',
                    '横向腮红增加脸部宽度'
                ]
            },
            '菱形脸': {
                matchScore: 86,
                differences: ['颧骨过于突出', '下巴略显尖瘦'],
                suggestions: [
                    '在颧骨位置使用哑光修容',
                    '下巴处打高光增加饱满度',
                    '眉形平直不宜过高',
                    '选择饱和度适中的口红'
                ]
            },
            '心形脸': {
                matchScore: 89,
                differences: ['额头偏宽', '下巴过尖'],
                suggestions: [
                    '在额头两侧使用修容',
                    '下巴处增加高光',
                    '眼妆不宜过于夸张',
                    '选择丰盈效果的口红'
                ]
            },
            '三角脸': {
                matchScore: 84,
                differences: ['下颌偏宽', '额头较窄'],
                suggestions: [
                    '重点提亮额头和太阳穴',
                    '修容在下颌角位置',
                    '眉毛加粗增加上半脸分量',
                    '选择明亮色系眼影'
                ]
            },
            '椭圆形脸': {
                matchScore: 92,
                differences: ['整体妆容较为平淡', '缺乏亮点'],
                suggestions: [
                    '选择一个重点妆容部位突出',
                    '使用珠光眼影增加层次感',
                    '尝试不同质地的口红',
                    '保持整体妆容的平衡感'
                ]
            }
        };
        
        const report = reports[faceShape] || reports['鹅蛋脸'];
        
        return {
            id: Date.now().toString(),
            faceShape,
            matchScore: report.matchScore,
            differences: report.differences,
            suggestions: report.suggestions,
            originalImage,
            referenceImage,
            timestamp: new Date().toISOString()
        };
    }
};

const CosmeticsData = {
    categories: ['全部化妆品', '底妆类', '彩妆类', '常用', '不常用'],
    types: ['粉底液', '气垫', '遮瑕', '散粉', '眼影', '腮红', '口红', '眉笔', '眼线', '高光', '修容', '睫毛膏'],
    zones: ['眼部', '面部', '唇部', '眉部', '全脸'],
    
    getAll() {
        const data = localStorage.getItem('cosmeticsList');
        if (!data) {
            return [];
        }
        try {
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        } catch {
            return [];
        }
    },
    
    add(cosmetic) {
        const all = this.getAll();
        const newItem = { ...cosmetic, id: Date.now().toString(), createdAt: new Date().toISOString() };
        all.unshift(newItem);
        localStorage.setItem('cosmeticsList', JSON.stringify(all));
        return all;
    },
    
    update(id, data) {
        const all = this.getAll();
        const index = all.findIndex(c => c.id === id);
        if (index !== -1) {
            all[index] = { ...all[index], ...data, updatedAt: new Date().toISOString() };
            localStorage.setItem('cosmeticsList', JSON.stringify(all));
        }
        return all;
    },
    
    delete(id) {
        const all = this.getAll();
        const filtered = all.filter(c => c.id !== id);
        localStorage.setItem('cosmeticsList', JSON.stringify(filtered));
        return filtered;
    },
    
    export() {
        const data = this.getAll();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `cosmetics_backup_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    },
    
    import(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    if (Array.isArray(data)) {
                        localStorage.setItem('cosmeticsList', JSON.stringify(data));
                        resolve(data);
                    } else {
                        reject(new Error('无效的文件格式'));
                    }
                } catch {
                    reject(new Error('文件解析失败'));
                }
            };
            reader.onerror = reject;
            reader.readAsText(file);
        });
    }
};

const MomentsData = {
    getPosts() {
        let posts = Storage.get('moments', []);
        if (posts.length === 0) {
            posts = this.getMockData();
            Storage.set('moments', posts);
        }
        return posts;
    },
    
    getMockData() {
        const avatar1 = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="45" fill="%23FFE4E1"/%3E%3Ccircle cx="50" cy="45" r="20" fill="%23FFB6C1"/%3E%3Ccircle cx="42" cy="42" r="4" fill="%23333"/%3E%3Ccircle cx="58" cy="42" r="4" fill="%23333"/%3E%3Cpath d="M42 58 Q50 65 58 58" stroke="%23E91E63" stroke-width="3" fill="none"/%3E%3C/svg%3E';
        const avatar2 = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="45" fill="%23FFF0F5"/%3E%3Ccircle cx="50" cy="45" r="22" fill="%23FFC0CB"/%3E%3Ccircle cx="40" cy="40" r="5" fill="%23333"/%3E%3Ccircle cx="60" cy="40" r="5" fill="%23333"/%3E%3Cpath d="M40 60 Q50 68 60 60" stroke="%23FF69B4" stroke-width="3" fill="none"/%3E%3C/svg%3E';
        const avatar3 = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="45" fill="%23FFFAF0"/%3E%3Ccircle cx="50" cy="45" r="20" fill="%23FFB6C1"/%3E%3Ccircle cx="44" cy="44" r="4" fill="%23333"/%3E%3Ccircle cx="56" cy="44" r="4" fill="%23333"/%3E%3Cpath d="M44 56 Q50 62 56 56" stroke="%23E91E63" stroke-width="3" fill="none"/%3E%3C/svg%3E';
        
        const image1 = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300"%3E%3Crect width="300" height="300" fill="%23FFF5F5"/%3E%3Ccircle cx="150" cy="120" r="60" fill="%23FFD700"/%3E%3Ccircle cx="120" cy="100" r="50" fill="%23FF69B4"/%3E%3Ccircle cx="180" cy="100" r="50" fill="%23FF1493"/%3E%3Ccircle cx="150" cy="150" r="45" fill="%23FFB6C1"/%3E%3Ctext x="150" y="250" text-anchor="middle" fill="%23FF69B4" font-size="18" font-family="sans-serif"%3E眼影盘%3C/text%3E%3C/svg%3E';
        const image2 = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300"%3E%3Crect width="300" height="300" fill="%23FFF0F5"/%3E%3Crect x="80" y="60" width="60" height="180" rx="10" fill="%23FFB6C1"/%3E%3Crect x="160" y="80" width="50" height="160" rx="10" fill="%23FFE4E1"/%3E%3Ccircle cx="110" cy="200" r="20" fill="%23FF69B4"/%3E%3Ccircle cx="185" cy="200" r="15" fill="%23FF1493"/%3E%3Ctext x="150" y="270" text-anchor="middle" fill="%23FF69B4" font-size="18" font-family="sans-serif"%3E护肤品%3C/text%3E%3C/svg%3E';
        const image3 = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300"%3E%3Crect width="300" height="300" fill="%23FFFAF0"/%3E%3Ccircle cx="150" cy="100" r="50" fill="%23FFE4E1"/%3E%3Ccircle cx="130" cy="90" r="4" fill="%23333"/%3E%3Ccircle cx="170" cy="90" r="4" fill="%23333"/%3E%3Cpath d="M130 115 Q150 125 170 115" stroke="%23FF69B4" stroke-width="3" fill="none"/%3E%3Crect x="120" y="180" width="60" height="80" rx="10" fill="%23FFB6C1"/%3E%3Ctext x="150" y="270" text-anchor="middle" fill="%23FF69B4" font-size="18" font-family="sans-serif"%3E美妆教程%3C/text%3E%3C/svg%3E';
        
        return [
            {
                id: '1',
                userId: 'mock1',
                username: '美妆达人小雅',
                avatar: avatar1,
                content: '今天尝试了一款新的眼影盘，颜色超级好看！推荐给大家~',
                images: [image1],
                tags: ['眼影', '美妆分享'],
                likes: 128,
                comments: [
                    { id: 'c1', userId: 'mock2', username: '小仙女', content: '好看！求链接~' },
                    { id: 'c2', userId: 'mock3', username: '美妆新手', content: '这个颜色适合新手吗？' }
                ],
                timestamp: new Date(Date.now() - 3600000).toISOString(),
                isLiked: false
            },
            {
                id: '2',
                userId: 'mock2',
                username: '护肤小白',
                avatar: avatar2,
                content: '最近皮肤状态超好，分享一下我的护肤心得！坚持每天护肤真的很重要~',
                images: [image2],
                tags: ['护肤', '日常'],
                likes: 89,
                comments: [
                    { id: 'c3', userId: 'mock1', username: '美妆达人小雅', content: '羡慕好皮肤！' }
                ],
                timestamp: new Date(Date.now() - 7200000).toISOString(),
                isLiked: false
            },
            {
                id: '3',
                userId: 'mock3',
                username: '时尚辣妈',
                avatar: avatar3,
                content: '周末带娃也要美美的！快速出门妆容教程来啦~',
                images: [image3],
                tags: ['日常妆容', '辣妈'],
                likes: 256,
                comments: [
                    { id: 'c4', userId: 'mock4', username: '上班族', content: '太实用了！收藏~' },
                    { id: 'c5', userId: 'mock5', username: '新手妈妈', content: '求详细教程！' },
                    { id: 'c6', userId: 'mock1', username: '美妆达人小雅', content: '妆容很精致！' }
                ],
                timestamp: new Date(Date.now() - 10800000).toISOString(),
                isLiked: true
            }
        ];
    },
    
    addPost(post) {
        const posts = this.getPosts();
        posts.unshift({ ...post, id: Date.now().toString(), timestamp: new Date().toISOString(), likes: 0, comments: [], isLiked: false });
        Storage.set('moments', posts);
        return posts;
    },
    
    updatePost(id, data) {
        const posts = this.getPosts();
        const index = posts.findIndex(p => p.id === id);
        if (index !== -1) {
            posts[index] = { ...posts[index], ...data };
            Storage.set('moments', posts);
        }
        return posts;
    },
    
    deletePost(id) {
        const posts = this.getPosts();
        const filtered = posts.filter(p => p.id !== id);
        Storage.set('moments', filtered);
        return filtered;
    },
    
    toggleLike(id) {
        const posts = this.getPosts();
        const post = posts.find(p => p.id === id);
        if (post) {
            post.isLiked = !post.isLiked;
            post.likes += post.isLiked ? 1 : -1;
            Storage.set('moments', posts);
        }
        return posts;
    },
    
    addComment(postId, comment) {
        const posts = this.getPosts();
        const post = posts.find(p => p.id === postId);
        if (post) {
            post.comments.push({ ...comment, id: Date.now().toString(), timestamp: new Date().toISOString() });
            Storage.set('moments', posts);
        }
        return posts;
    },
    
    deleteComment(postId, commentId) {
        const posts = this.getPosts();
        const post = posts.find(p => p.id === postId);
        if (post) {
            post.comments = post.comments.filter(c => c.id !== commentId);
            Storage.set('moments', posts);
        }
        return posts;
    }
};

const UserData = {
    getCurrentUser() {
        return Storage.get('currentUser', null);
    },
    
    setCurrentUser(user) {
        Storage.set('currentUser', user);
    },
    
    clearSession() {
        Storage.remove('currentUser');
    },
    
    getUsers() {
        return Storage.get('users', []);
    },
    
    createUser(user) {
        const users = this.getUsers();
        users.push({ ...user, id: Date.now().toString(), createdAt: new Date().toISOString() });
        Storage.set('users', users);
        return users;
    },
    
    updateUser(id, data) {
        const users = this.getUsers();
        const index = users.findIndex(u => u.id === id);
        if (index !== -1) {
            users[index] = { ...users[index], ...data };
            Storage.set('users', users);
            const currentUser = this.getCurrentUser();
            if (currentUser && currentUser.id === id) {
                this.setCurrentUser(users[index]);
            }
        }
        return users;
    },
    
    generateNickname() {
        const adjectives = ['甜美', '可爱', '温柔', '优雅', '灵动', '俏皮', '清新', '靓丽'];
        const nouns = ['小仙女', '美妆师', '甜心', '公主', '宝贝', '美人', '女神', '天使'];
        const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
        const noun = nouns[Math.floor(Math.random() * nouns.length)];
        const num = Math.floor(Math.random() * 1000);
        return `${adj}${noun}${num}`;
    }
};

const PostDraft = {
    get() {
        return Storage.get('postDraft', null);
    },
    
    set(draft) {
        Storage.set('postDraft', draft);
    },
    
    clear() {
        Storage.remove('postDraft');
    }
};

const BanWords = [
    '傻逼', '傻B', 'SB', '卧槽', '他妈的', '你妈', '尼玛', '去死', '滚', '垃圾',
    '操', 'fuck', 'shit', 'bitch', 'damn', '该死', '混蛋', '智障', '脑瘫', '脑残',
    '色情', '色情内容', '性', '裸体', '露骨', '变态', '强奸', '卖淫', '嫖娼',
    '赌博', '毒品', '吸毒', '贩毒', '枪支', '暴力', '血腥', '恐怖', '杀人'
];

const BanWordsFilter = {
    hasBanWords(text) {
        if (!text) return false;
        return BanWords.some(word => text.includes(word));
    },
    
    filter(text) {
        if (!text) return text;
        let result = text;
        BanWords.forEach(word => {
            result = result.replace(new RegExp(word, 'gi'), '*'.repeat(word.length));
        });
        return result;
    }
};
