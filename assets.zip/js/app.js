let currentUser = null;
let currentPage = 'home';
let currentFaceImage = null;
let currentReport = null;
let currentCategory = '全部化妆品';
let momentsSort = 'latest';

function init() {
    migrateCosmeticsData();
    Voice.init();
    checkLogin();
    setupEventListeners();
    loadSavedPhotos();
}

function migrateCosmeticsData() {
    const oldData = localStorage.getItem('cosmetics');
    const newData = localStorage.getItem('cosmeticsList');
    
    if (oldData && !newData) {
        try {
            const parsed = JSON.parse(oldData);
            if (Array.isArray(parsed)) {
                localStorage.setItem('cosmeticsList', JSON.stringify(parsed));
                localStorage.removeItem('cosmetics');
            }
        } catch {
            console.error('Failed to migrate cosmetics data');
        }
    }
}

function checkLogin() {
    const user = UserData.getCurrentUser();
    if (user) {
        currentUser = user;
        document.getElementById('login-modal').classList.remove('show');
    } else {
        document.getElementById('login-modal').classList.add('show');
    }
}

function setupEventListeners() {
    document.getElementById('login-btn').addEventListener('click', handleLogin);
    document.getElementById('generate-nickname').addEventListener('click', generateRandomNickname);
    document.getElementById('avatar-upload').addEventListener('click', () => document.getElementById('avatar-file').click());
    document.getElementById('avatar-file').addEventListener('change', handleAvatarUpload);

    document.getElementById('face-upload').addEventListener('click', () => document.getElementById('face-file').click());
    document.getElementById('face-file').addEventListener('change', handleFaceUpload);

    document.getElementById('cosmetic-image-upload').addEventListener('click', () => document.getElementById('cosmetic-image-file').click());
    document.getElementById('cosmetic-image-file').addEventListener('change', handleCosmeticImageUpload);

    document.getElementById('post-image-upload').addEventListener('click', () => document.getElementById('post-image-file').click());
    document.getElementById('post-image-file').addEventListener('change', handlePostImageUpload);

    document.getElementById('import-file').addEventListener('change', handleImportFile);



    document.getElementById('voice-toggle').addEventListener('change', toggleVoice);
}

function generateRandomNickname() {
    document.getElementById('login-nickname').value = UserData.generateNickname();
}

function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if (file) {
        ImageCompressor.compress(file, 200, 200).then(base64 => {
            document.getElementById('avatar-preview').src = base64;
        });
    }
}

function handleLogin() {
    const nickname = document.getElementById('login-nickname').value.trim();
    const avatar = document.getElementById('avatar-preview').src;

    if (!nickname) {
        Toast.warning('请输入昵称');
        return;
    }

    const user = {
        nickname,
        avatar,
        bio: '热爱美妆的小仙女',
        level: '新手',
        createdAt: new Date().toISOString()
    };

    UserData.setCurrentUser(user);
    currentUser = user;
    document.getElementById('login-modal').classList.remove('show');
    Toast.success('登录成功');
}

function navigateTo(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-item').forEach(t => t.classList.remove('active'));
    
    document.getElementById(`page-${pageId}`).classList.add('active');
    
    const tabIndex = ['home', 'makeup-artist', 'cosmetics', 'moments', 'profile'].indexOf(pageId);
    if (tabIndex !== -1) {
        document.querySelectorAll('.tab-item')[tabIndex].classList.add('active');
    }

    currentPage = pageId;

    if (pageId === 'moments') {
        loadMoments();
    } else if (pageId === 'cosmetics') {
        loadCosmetics();
    } else if (pageId === 'profile') {
        loadProfile();
    } else if (pageId === 'makeup-artist') {
        resetMakeup();
    }
}

function goToUpload() {
    const link = document.getElementById('douyin-link').value.trim();
    if (!link) {
        Toast.warning('请粘贴抖音链接');
        return;
    }
    document.getElementById('makeup-step-1').style.display = 'none';
    document.getElementById('makeup-step-2').style.display = 'block';
}

function handleFaceUpload(e) {
    const file = e.target.files[0];
    if (file) {
        ImageCompressor.compress(file).then(base64 => {
            currentFaceImage = base64;
            const preview = document.getElementById('face-preview');
            preview.src = base64;
            preview.style.display = 'block';
            document.getElementById('detect-btn').disabled = false;

            const savedPhotos = Storage.get('savedPhotos', []);
            if (!savedPhotos.includes(base64)) {
                savedPhotos.push(base64);
                if (savedPhotos.length > 10) savedPhotos.shift();
                Storage.set('savedPhotos', savedPhotos);
                loadSavedPhotos();
            }
        });
    }
}

function loadSavedPhotos() {
    const savedPhotos = Storage.get('savedPhotos', []);
    const container = document.getElementById('saved-photos');
    container.innerHTML = '';
    
    savedPhotos.forEach((photo, index) => {
        const item = document.createElement('div');
        item.className = 'list-item';
        item.style.cursor = 'pointer';
        item.innerHTML = `
            <div class="img-wrapper" style="width: 50px; height: 50px;">
                <img src="${photo}" alt="存档照片">
            </div>
            <div class="content">
                <div class="title">存档照片 ${savedPhotos.length - index}</div>
                <div class="desc">点击使用</div>
            </div>
        `;
        item.onclick = () => {
            currentFaceImage = photo;
            const preview = document.getElementById('face-preview');
            preview.src = photo;
            preview.style.display = 'block';
            document.getElementById('detect-btn').disabled = false;
        };
        container.appendChild(item);
    });

    if (savedPhotos.length === 0) {
        container.innerHTML = '<p class="text-muted text-center small">暂无存档照片</p>';
    }
}

async function detectFace() {
    if (!currentFaceImage) return;

    document.getElementById('makeup-step-2').style.display = 'none';
    document.getElementById('makeup-step-3').style.display = 'block';

    const progressBar = document.getElementById('detect-progress');
    let progress = 0;
    const interval = setInterval(() => {
        progress += 5;
        progressBar.style.width = `${progress}%`;
        if (progress >= 100) clearInterval(interval);
    }, 100);

    const img = new Image();
    img.onload = async () => {
        const hasFace = await FaceDetector.detect(img);
        
        clearInterval(interval);
        progressBar.style.width = '100%';

        setTimeout(() => {
            document.getElementById('makeup-step-3').style.display = 'none';
            
            if (hasFace) {
                analyzeFace(img);
            } else {
                Modal.alert('未检测到人脸，请重新上传照片', () => {
                    document.getElementById('makeup-step-2').style.display = 'block';
                });
            }
        }, 500);
    };
    img.src = currentFaceImage;

    await FaceDetector.loadModel();
}

function generateMakeupReference(faceShape) {
    const colors = {
        '鹅蛋脸': ['#FFD700', '#FF69B4', '#FFB6C1'],
        '圆脸': ['#FF69B4', '#FF1493', '#FFE4E1'],
        '方脸': ['#FFB6C1', '#E91E63', '#FFF0F5'],
        '长脸': ['#FF1493', '#FF69B4', '#FFFAF0'],
        '菱形脸': ['#E91E63', '#FFB6C1', '#FFF5F5'],
        '心形脸': ['#FF69B4', '#FFD700', '#FFE4E1'],
        '三角脸': ['#FFB6C1', '#FF69B4', '#FFF0F5'],
        '椭圆形脸': ['#FFD700', '#E91E63', '#FFFAF0']
    };
    
    const colorSet = colors[faceShape] || colors['鹅蛋脸'];
    const bgColor = '#FFF5F5';
    const eyeColor = colorSet[0];
    const cheekColor = colorSet[1];
    const lipColor = colorSet[2];
    
    return `data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300"%3E%3Crect width="300" height="300" fill="${bgColor.replace('#', '%23')}"/%3E%3Ccircle cx="150" cy="150" r="80" fill="%23FFE4E1"/%3E%3Ccircle cx="120" cy="130" r="15" fill="%23FFF"/%3E%3Ccircle cx="120" cy="130" r="8" fill="${eyeColor.replace('#', '%23')}"/%3E%3Ccircle cx="180" cy="130" r="15" fill="%23FFF"/%3E%3Ccircle cx="180" cy="130" r="8" fill="${eyeColor.replace('#', '%23')}"/%3E%3Cellipse cx="120" cy="140" rx="18" ry="8" fill="${eyeColor.replace('#', '%23')}" opacity="0.5"/%3E%3Cellipse cx="180" cy="140" rx="18" ry="8" fill="${eyeColor.replace('#', '%23')}" opacity="0.5"/%3E%3Cellipse cx="100" cy="160" rx="20" ry="12" fill="${cheekColor.replace('#', '%23')}" opacity="0.4"/%3E%3Cellipse cx="200" cy="160" rx="20" ry="12" fill="${cheekColor.replace('#', '%23')}" opacity="0.4"/%3E%3Cpath d="M120 190 Q150 210 180 190" stroke="${lipColor.replace('#', '%23')}" stroke-width="8" fill="none" stroke-linecap="round"/%3E%3Ctext x="150" y="270" text-anchor="middle" fill="%23FF69B4" font-size="16" font-family="sans-serif"%3E${encodeURIComponent(faceShape)}妆容参考%3C/text%3E%3C/svg%3E`;
}

function analyzeFace(img) {
    const faceShape = FaceShapeAnalyzer.analyze(img);
    const analysisText = FaceShapeAnalyzer.getAnalysisText(faceShape);

    const referenceImage = generateMakeupReference(faceShape);

    currentReport = MakeupReportGenerator.generate(faceShape, currentFaceImage, referenceImage);

    document.getElementById('face-shape-tag').textContent = faceShape;
    document.getElementById('face-shape-title').textContent = `您的脸型是${faceShape}`;
    document.getElementById('face-analysis-text').textContent = analysisText;
    document.getElementById('report-original').src = currentFaceImage;
    document.getElementById('report-reference').src = referenceImage;
    document.getElementById('match-score').textContent = `${currentReport.matchScore}%`;
    document.getElementById('match-progress').style.width = `${currentReport.matchScore}%`;

    const differencesList = document.getElementById('differences-list');
    differencesList.innerHTML = currentReport.differences.map(d => `<li style="color: #666; margin-bottom: 4px;">• ${d}</li>`).join('');

    const suggestionsList = document.getElementById('suggestions-list');
    suggestionsList.innerHTML = currentReport.suggestions.map((s, i) => `<li style="color: #666; margin-bottom: 6px;">${i + 1}. ${s}</li>`).join('');

    document.getElementById('makeup-step-4').style.display = 'block';

    Voice.speak(analysisText);
}

function resetMakeup() {
    document.getElementById('makeup-step-1').style.display = 'block';
    document.getElementById('makeup-step-2').style.display = 'none';
    document.getElementById('makeup-step-3').style.display = 'none';
    document.getElementById('makeup-step-4').style.display = 'none';
    document.getElementById('douyin-link').value = '';
    document.getElementById('face-file').value = '';
    document.getElementById('face-preview').style.display = 'none';
    document.getElementById('detect-btn').disabled = true;
    currentFaceImage = null;
    currentReport = null;
}

function shareReport() {
    Toast.success('分享链接已复制');
}

function findBloggers() {
    if (!currentReport) return;
    const bloggers = [
        { name: '美妆达人A', link: 'https://www.douyin.com/user/MS4wLjABAAAAxxx' },
        { name: '妆容教程B', link: 'https://www.douyin.com/user/MS4wLjABAAAAyyy' },
        { name: '护肤专家C', link: 'https://www.douyin.com/user/MS4wLjABAAAAzzz' }
    ];

    const html = bloggers.map(b => 
        `<div class="list-item" style="cursor: pointer;" onclick="window.open('${b.link}')">
            <div class="content">
                <div class="title">${b.name}</div>
                <div class="desc">点击跳转抖音</div>
            </div>
            <i class="fa-solid fa-external-link-alt text-muted"></i>
        </div>`
    ).join('');

    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">适配博主推荐</div>
            <div class="modal-body" style="text-align: left;">${html}</div>
            <div class="modal-footer">
                <button class="btn" onclick="this.closest('.modal').remove()">关闭</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function publishToMoments() {
    if (!currentReport) return;

    const draft = {
        content: `${currentReport.faceShape}妆容分析报告\n匹配度：${currentReport.matchScore}%\n\n推荐妆容方案：\n${currentReport.suggestions.join('\n')}`,
        images: [currentReport.originalImage, currentReport.referenceImage],
        tags: [currentReport.faceShape, '妆容复刻']
    };

    PostDraft.set(draft);
    navigateTo('moments');
    
    setTimeout(() => {
        openPostModal();
    }, 500);
}

function loadCosmetics() {
    const container = document.getElementById('cosmetics-list');
    
    container.innerHTML = '';
    
    const data = localStorage.getItem('cosmeticsList');
    let allCosmetics = [];
    if (data) {
        try {
            const parsed = JSON.parse(data);
            allCosmetics = Array.isArray(parsed) ? parsed : [];
        } catch {
            allCosmetics = [];
        }
    }
    
    let cosmetics = [];
    if (currentCategory === '全部化妆品') {
        cosmetics = allCosmetics;
    } else if (currentCategory === '底妆类') {
        cosmetics = allCosmetics.filter(c => ['粉底液', '气垫', '遮瑕', '散粉'].includes(c.type));
    } else if (currentCategory === '彩妆类') {
        cosmetics = allCosmetics.filter(c => !['粉底液', '气垫', '遮瑕', '散粉'].includes(c.type));
    } else if (currentCategory === '常用') {
        cosmetics = allCosmetics.filter(c => c.frequency === '高');
    } else if (currentCategory === '不常用') {
        cosmetics = allCosmetics.filter(c => c.frequency === '低');
    }
    
    if (cosmetics.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">暂无化妆品，点击右下角加号添加</p>';
        return;
    }

    const html = [];
    for (let i = 0; i < cosmetics.length; i++) {
        const c = cosmetics[i];
        const daysRemaining = DateUtils.getDaysRemaining(new Date(), c.expiry);
        const isExpiring = daysRemaining < 30;
        const isExpired = daysRemaining < 0;

        html.push(`
            <div class="list-item ${isExpiring ? 'border-danger' : ''}" style="${isExpiring ? 'border-color: #FF4757;' : ''}">
                <div class="img-wrapper">
                    <img src="${c.image || 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60"%3E%3Crect width="60" height="60" fill="%23FFE4E1"/%3E%3Ctext x="30" y="35" text-anchor="middle" fill="%23FFB6C1" font-size="24" font-family="sans-serif"%3E💄%3C/text%3E%3C/svg%3E'}" alt="${c.name}">
                </div>
                <div class="content">
                    <div class="title" style="${isExpiring ? 'color: #FF4757;' : ''}">${c.name}</div>
                    <div class="desc">${c.type} · ${c.shade}</div>
                    <div class="small" style="${isExpired ? 'color: #FF4757;' : isExpiring ? 'color: #FFA502;' : ''}">
                        ${isExpired ? '已过期' : isExpiring ? `保质期剩余 ${daysRemaining} 天` : `有效期至 ${c.expiry}`}
                    </div>
                </div>
                <div class="action">
                    <button class="btn btn-outline" style="padding: 6px 12px; font-size: 12px;" onclick="editCosmetic('${c.id}')">编辑</button>
                    <button class="btn btn-outline" style="padding: 6px 12px; font-size: 12px; color: #FF4757; border-color: #FF4757;" onclick="deleteCosmetic('${c.id}')">删除</button>
                </div>
            </div>
        `);
    }
    
    container.innerHTML = html.join('');
}

function filterCosmetics(category) {
    currentCategory = category;
    document.querySelectorAll('.cosmetic-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`[data-category="${category}"]`).classList.add('active');
    loadCosmetics();
}

function openCosmeticModal(id = null) {
    document.getElementById('cosmetic-modal-title').textContent = id ? '编辑化妆品' : '新增化妆品';
    document.getElementById('cosmetic-id').value = id || '';
    
    if (id) {
        const data = localStorage.getItem('cosmeticsList');
        let cosmetics = [];
        if (data) {
            try {
                const parsed = JSON.parse(data);
                cosmetics = Array.isArray(parsed) ? parsed : [];
            } catch {
                cosmetics = [];
            }
        }
        const cosmetic = cosmetics.find(c => c.id === id);
        if (cosmetic) {
            document.getElementById('cosmetic-name').value = cosmetic.name;
            document.getElementById('cosmetic-type').value = cosmetic.type;
            document.getElementById('cosmetic-shade').value = cosmetic.shade;
            document.getElementById('cosmetic-production').value = cosmetic.production;
            document.getElementById('cosmetic-expiry').value = cosmetic.expiry;
            document.getElementById('cosmetic-frequency').value = cosmetic.frequency;
            document.getElementById('cosmetic-zone').value = cosmetic.zone;
            if (cosmetic.image) {
                document.getElementById('cosmetic-image-preview').src = cosmetic.image;
                document.getElementById('cosmetic-image-preview').style.display = 'block';
                document.getElementById('cosmetic-image-text').style.display = 'none';
            }
        }
    } else {
        document.getElementById('cosmetic-name').value = '';
        document.getElementById('cosmetic-type').value = '';
        document.getElementById('cosmetic-shade').value = '';
        document.getElementById('cosmetic-production').value = '';
        document.getElementById('cosmetic-expiry').value = '';
        document.getElementById('cosmetic-frequency').value = '';
        document.getElementById('cosmetic-zone').value = '';
        document.getElementById('cosmetic-image-preview').style.display = 'none';
        document.getElementById('cosmetic-image-text').style.display = 'block';
    }

    document.getElementById('cosmetic-modal').classList.add('show');
}

function closeCosmeticModal() {
    document.getElementById('cosmetic-modal').classList.remove('show');
}

function handleCosmeticImageUpload(e) {
    const file = e.target.files[0];
    if (file) {
        ImageCompressor.compress(file, 400, 400).then(base64 => {
            document.getElementById('cosmetic-image-preview').src = base64;
            document.getElementById('cosmetic-image-preview').style.display = 'block';
            document.getElementById('cosmetic-image-text').style.display = 'none';
        });
    }
}

function validateCosmeticFormStrict() {
    const name = document.getElementById('cosmetic-name').value.trim();
    const type = document.getElementById('cosmetic-type').value;
    const shade = document.getElementById('cosmetic-shade').value.trim();
    const production = document.getElementById('cosmetic-production').value;
    const expiry = document.getElementById('cosmetic-expiry').value;
    const frequency = document.getElementById('cosmetic-frequency').value;
    const zone = document.getElementById('cosmetic-zone').value;

    if (!name) {
        Toast.warning('请填写化妆品名称');
        document.getElementById('cosmetic-name').focus();
        return false;
    }
    if (!type) {
        Toast.warning('请选择品类');
        document.getElementById('cosmetic-type').focus();
        return false;
    }
    if (!shade) {
        Toast.warning('请填写色号');
        document.getElementById('cosmetic-shade').focus();
        return false;
    }
    if (!production) {
        Toast.warning('请选择生产日期');
        document.getElementById('cosmetic-production').focus();
        return false;
    }
    if (!expiry) {
        Toast.warning('请选择保质期');
        document.getElementById('cosmetic-expiry').focus();
        return false;
    }
    if (!frequency) {
        Toast.warning('请选择使用频次');
        document.getElementById('cosmetic-frequency').focus();
        return false;
    }
    if (!zone) {
        Toast.warning('请选择彩妆分区');
        document.getElementById('cosmetic-zone').focus();
        return false;
    }

    if (DateUtils.isBefore(expiry, production)) {
        Toast.warning('保质期不能早于生产日期');
        return false;
    }

    return true;
}

function saveCosmetic() {
    if (!validateCosmeticFormStrict()) {
        return;
    }

    const id = document.getElementById('cosmetic-id').value;
    const name = document.getElementById('cosmetic-name').value.trim();
    const type = document.getElementById('cosmetic-type').value;
    const shade = document.getElementById('cosmetic-shade').value.trim();
    const production = document.getElementById('cosmetic-production').value;
    const expiry = document.getElementById('cosmetic-expiry').value;
    const frequency = document.getElementById('cosmetic-frequency').value;
    const zone = document.getElementById('cosmetic-zone').value;
    const image = document.getElementById('cosmetic-image-preview').src;

    const cosmetic = {
        name, type, shade, production, expiry, frequency, zone,
        image: image.startsWith('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60') ? '' : image
    };

    if (id) {
        CosmeticsData.update(id, cosmetic);
        Toast.success('更新成功');
    } else {
        CosmeticsData.add(cosmetic);
        Toast.success('添加成功');
    }

    closeCosmeticModal();
    loadCosmetics();
}

function editCosmetic(id) {
    openCosmeticModal(id);
}

function deleteCosmetic(id) {
    Modal.confirm('确定要删除这个化妆品吗？', () => {
        CosmeticsData.delete(id);
        Toast.success('删除成功');
        loadCosmetics();
    });
}

function exportCosmetics() {
    CosmeticsData.export();
    Toast.success('导出成功');
}

function importCosmetics() {
    document.getElementById('import-file').click();
}

function handleImportFile(e) {
    const file = e.target.files[0];
    if (file) {
        CosmeticsData.import(file).then(() => {
            Toast.success('导入成功');
            loadCosmetics();
        }).catch(() => {
            Toast.error('导入失败，文件格式不正确');
        });
    }
}

function loadMoments() {
    let posts = MomentsData.getPosts();
    
    if (momentsSort === 'liked') {
        posts = [...posts].sort((a, b) => b.likes - a.likes);
    }

    const container = document.getElementById('moments-list');
    container.innerHTML = posts.map(post => {
        const isMyPost = currentUser && post.userId === currentUser.id;
        const timeAgo = formatTimeAgo(new Date(post.timestamp));

        return `
            <div class="card">
                <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <img src="${post.avatar}" class="avatar-sm" alt="${post.username}">
                    <div style="margin-left: 12px;">
                        <div style="font-weight: 600;">${post.username}</div>
                        <div class="small text-muted">${timeAgo}</div>
                    </div>
                    ${isMyPost ? `
                        <div style="margin-left: auto;">
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 12px;" onclick="editPost('${post.id}')">编辑</button>
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 12px; color: #FF4757; border-color: #FF4757;" onclick="deletePost('${post.id}')">删除</button>
                        </div>
                    ` : ''}
                </div>
                
                <div style="font-size: 14px; color: #333; margin-bottom: 12px;">${post.content}</div>
                
                ${post.images && post.images.length > 0 ? `
                    <div style="display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap;">
                        ${post.images.map(img => `<img src="${img}" style="max-width: 100px; max-height: 100px; border-radius: 8px;">`).join('')}
                    </div>
                ` : ''}
                
                ${post.tags && post.tags.length > 0 ? `
                    <div style="display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap;">
                        ${post.tags.map(tag => `<span class="badge">#${tag}</span>`).join('')}
                    </div>
                ` : ''}
                
                <div style="display: flex; gap: 20px; padding-top: 12px; border-top: 1px solid #FFE4E1;">
                    <div style="display: flex; align-items: center; gap: 6px; cursor: pointer;" onclick="togglePostLike('${post.id}')">
                        <i class="fa-solid fa-heart ${post.isLiked ? 'text-danger' : 'text-muted'}"></i>
                        <span class="small">${post.likes}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 6px; cursor: pointer;" onclick="openComments('${post.id}')">
                        <i class="fa-solid fa-comment text-muted"></i>
                        <span class="small">${post.comments.length}</span>
                    </div>
                </div>
                
                ${post.comments && post.comments.length > 0 ? `
                    <div style="margin-top: 12px; padding-top: 12px; border-top: 1px dashed #FFE4E1;">
                        ${post.comments.map(comment => `
                            <div style="display: flex; margin-bottom: 8px;">
                                <img src="${comment.avatar || post.avatar}" class="avatar-sm" style="width: 24px; height: 24px;">
                                <div style="margin-left: 8px; flex: 1;">
                                    <div style="font-weight: 500; font-size: 13px;">${comment.username}</div>
                                    <div style="font-size: 13px; color: #666;">${comment.content}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                ` : ''}
                
                <div style="display: flex; gap: 8px; margin-top: 12px;">
                    <input type="text" class="form-input" style="flex: 1; font-size: 13px; padding: 8px 12px;" placeholder="发表评论..." id="comment-input-${post.id}">
                    <button class="btn btn-outline" style="padding: 8px 16px; font-size: 13px;" onclick="submitComment('${post.id}')">发送</button>
                </div>
            </div>
        `;
    }).join('');
}

function sortMoments(sort) {
    momentsSort = sort;
    document.querySelectorAll('.moments-sort').forEach(s => s.classList.remove('active'));
    document.querySelector(`[data-sort="${sort}"]`).classList.add('active');
    loadMoments();
}

function formatTimeAgo(date) {
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return '刚刚';
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    return `${days}天前`;
}

function openPostModal() {
    const draft = PostDraft.get();
    if (draft) {
        document.getElementById('post-content').value = draft.content;
        document.getElementById('post-tags').value = draft.tags.join(',');
        const preview = document.getElementById('post-images-preview');
        preview.innerHTML = draft.images.map((img, i) => `
            <img src="${img}" style="width: 80px; height: 80px; border-radius: 8px; position: relative;">
            <button onclick="removePostImage(${i})" style="position: absolute; top: -5px; right: -5px; background: #FF4757; color: #fff; border: none; border-radius: 50%; width: 20px; height: 20px; font-size: 12px;">×</button>
        `).join('');
        window.postImages = draft.images;
        PostDraft.clear();
    } else {
        document.getElementById('post-content').value = '';
        document.getElementById('post-tags').value = '';
        document.getElementById('post-images-preview').innerHTML = '';
        window.postImages = [];
    }

    document.getElementById('post-modal').classList.add('show');
}

function closePostModal() {
    document.getElementById('post-modal').classList.remove('show');
}

function handlePostImageUpload(e) {
    const file = e.target.files[0];
    if (file) {
        ImageCompressor.compress(file, 600, 600).then(base64 => {
            if (!window.postImages) window.postImages = [];
            window.postImages.push(base64);
            const preview = document.getElementById('post-images-preview');
            const index = window.postImages.length - 1;
            preview.innerHTML += `
                <div style="position: relative;">
                    <img src="${base64}" style="width: 80px; height: 80px; border-radius: 8px;">
                    <button onclick="removePostImage(${index})" style="position: absolute; top: -8px; right: -8px; background: #FF4757; color: #fff; border: none; border-radius: 50%; width: 24px; height: 24px; font-size: 14px;">×</button>
                </div>
            `;
        });
    }
}

function removePostImage(index) {
    if (window.postImages) {
        window.postImages.splice(index, 1);
        const preview = document.getElementById('post-images-preview');
        preview.innerHTML = window.postImages.map((img, i) => `
            <div style="position: relative;">
                <img src="${img}" style="width: 80px; height: 80px; border-radius: 8px;">
                <button onclick="removePostImage(${i})" style="position: absolute; top: -8px; right: -8px; background: #FF4757; color: #fff; border: none; border-radius: 50%; width: 24px; height: 24px; font-size: 14px;">×</button>
            </div>
        `).join('');
    }
}

function submitPost() {
    const content = document.getElementById('post-content').value.trim();
    const tags = document.getElementById('post-tags').value.split(',').map(t => t.trim()).filter(t => t);
    const images = window.postImages || [];

    if (!content && images.length === 0) {
        Toast.warning('请输入内容或添加图片');
        return;
    }

    if (BanWordsFilter.hasBanWords(content)) {
        Toast.warning('内容包含违禁词，请修改后重试');
        return;
    }

    const postData = {
        userId: currentUser.id,
        username: currentUser.nickname,
        avatar: currentUser.avatar,
        content: BanWordsFilter.filter(content),
        images,
        tags
    };

    if (window.editingPostId) {
        MomentsData.updatePost(window.editingPostId, postData);
        window.editingPostId = null;
        Toast.success('更新成功');
    } else {
        MomentsData.addPost(postData);
        Toast.success('发布成功');
    }

    closePostModal();
    loadMoments();
}

function togglePostLike(postId) {
    MomentsData.toggleLike(postId);
    loadMoments();
}

function openComments(postId) {
    const postElement = document.querySelector(`[onclick="togglePostLike('${postId}')"]`).closest('.card');
    if (postElement) {
        postElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function submitComment(postId) {
    const input = document.getElementById(`comment-input-${postId}`);
    const content = input.value.trim();

    if (!content) return;

    if (BanWordsFilter.hasBanWords(content)) {
        Toast.warning('评论包含违禁词，请修改后重试');
        return;
    }

    const comment = {
        userId: currentUser.id,
        username: currentUser.nickname,
        avatar: currentUser.avatar,
        content: BanWordsFilter.filter(content)
    };

    MomentsData.addComment(postId, comment);
    input.value = '';
    loadMoments();
}

function deletePost(postId) {
    Modal.confirm('确定要删除这条帖子吗？', () => {
        MomentsData.deletePost(postId);
        loadMoments();
        Toast.success('删除成功');
    });
}

function editPost(postId) {
    const posts = MomentsData.getPosts();
    const post = posts.find(p => p.id === postId);
    if (!post) return;

    document.getElementById('post-content').value = post.content;
    document.getElementById('post-tags').value = (post.tags || []).join(',');
    window.postImages = post.images || [];
    
    const preview = document.getElementById('post-images-preview');
    preview.innerHTML = window.postImages.map((img, i) => `
        <div style="position: relative;">
            <img src="${img}" style="width: 80px; height: 80px; border-radius: 8px;">
            <button onclick="removePostImage(${i})" style="position: absolute; top: -8px; right: -8px; background: #FF4757; color: #fff; border: none; border-radius: 50%; width: 24px; height: 24px; font-size: 14px;">×</button>
        </div>
    `).join('');

    window.editingPostId = postId;
    document.getElementById('post-modal').classList.add('show');
}

function loadProfile() {
    if (!currentUser) return;

    document.getElementById('profile-avatar').src = currentUser.avatar;
    document.getElementById('profile-nickname').textContent = currentUser.nickname;
    document.getElementById('profile-bio').textContent = currentUser.bio || '热爱美妆的小仙女';

    const posts = MomentsData.getPosts();
    const myPosts = posts.filter(p => p.userId === currentUser.id);
    document.getElementById('post-count').textContent = myPosts.length;

    const cosmetics = CosmeticsData.getAll();
    document.getElementById('cosmetic-count').textContent = cosmetics.length;

    const totalLikes = myPosts.reduce((sum, p) => sum + p.likes, 0);
    document.getElementById('like-count').textContent = totalLikes;

    document.getElementById('voice-toggle').checked = Voice.enabled;
    document.getElementById('voice-status').textContent = Voice.enabled ? '已开启' : '已关闭';
}

function openSettings() {
    document.getElementById('settings-modal').classList.add('show');
}

function closeSettings() {
    document.getElementById('settings-modal').classList.remove('show');
}

function toggleVoice() {
    const enabled = document.getElementById('voice-toggle').checked;
    Voice.setEnabled(enabled);
    document.getElementById('voice-status').textContent = enabled ? '已开启' : '已关闭';
    if (enabled) {
        Voice.speak('语音播报已开启');
    }
}

function openEditProfile() {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">修改昵称和头像</div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">昵称</label>
                    <input type="text" id="edit-nickname" class="form-input" value="${currentUser.nickname}">
                </div>
                <div class="form-group">
                    <label class="form-label">头像</label>
                    <div class="upload-area" id="edit-avatar-upload" style="padding: 20px;">
                        <img id="edit-avatar-preview" src="${currentUser.avatar}" class="avatar" style="margin: 0 auto 12px;">
                        <input type="file" id="edit-avatar-file" accept="image/*" style="display: none;">
                        <span class="text" style="font-size: 14px;">点击更换头像</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="this.closest('.modal').remove()">取消</button>
                <button class="btn" onclick="saveProfile()">保存</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('edit-avatar-upload').addEventListener('click', () => document.getElementById('edit-avatar-file').click());
    document.getElementById('edit-avatar-file').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            ImageCompressor.compress(file, 200, 200).then(base64 => {
                document.getElementById('edit-avatar-preview').src = base64;
            });
        }
    });
}

function saveProfile() {
    const nickname = document.getElementById('edit-nickname').value.trim();
    const avatar = document.getElementById('edit-avatar-preview').src;

    if (!nickname) {
        Toast.warning('请输入昵称');
        return;
    }

    currentUser.nickname = nickname;
    currentUser.avatar = avatar;
    UserData.setCurrentUser(currentUser);

    document.querySelector('.modal.show').remove();
    loadProfile();
    Toast.success('修改成功');
}

function openEditBio() {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">编辑简介</div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">美妆简介</label>
                    <textarea id="edit-bio" class="form-textarea">${currentUser.bio || ''}</textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="this.closest('.modal').remove()">取消</button>
                <button class="btn" onclick="saveBio()">保存</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function saveBio() {
    const bio = document.getElementById('edit-bio').value.trim();
    currentUser.bio = bio;
    UserData.setCurrentUser(currentUser);

    document.querySelector('.modal.show').remove();
    loadProfile();
    Toast.success('修改成功');
}

function openEditLevel() {
    const levels = ['新手', '入门', '进阶', '专业', '大师'];
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">化妆水平标签</div>
            <div class="modal-body">
                <div style="display: flex; flex-wrap: wrap; gap: 12px;">
                    ${levels.map(l => `
                        <button class="btn ${currentUser.level === l ? '' : 'btn-outline'}" onclick="selectLevel('${l}')">${l}</button>
                    `).join('')}
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn" onclick="this.closest('.modal').remove()">确认</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function selectLevel(level) {
    currentUser.level = level;
    UserData.setCurrentUser(currentUser);

    document.querySelectorAll('.modal.show .btn').forEach(b => b.className = 'btn btn-outline');
    event.target.className = 'btn';

    Toast.success(`已选择${level}`);
}

function logout() {
    Modal.confirm('确定要退出登录吗？数据将保留在本地', () => {
        UserData.clearSession();
        currentUser = null;
        document.getElementById('settings-modal').classList.remove('show');
        document.getElementById('login-modal').classList.add('show');
        navigateTo('home');
        Toast.success('已退出登录');
    });
}

document.addEventListener('DOMContentLoaded', init);
